
# coding: utf-8

# * Create .py model file as per the coding standards.
#     * It means we need 3 notebooks. 
#         * Development.pynb for initial development of models and runs.
#         * Implementation.py which is modified version of Development.pynb with changes as per Watson Coding Standards.
#             * Remember that we can seperate data cleansing in a seperate file  and call that in Implementation.Not mandatory.
#         * Deployment.pynb is to deploy the Implementation.py to Cloud & run.
#     * Implementation.py will have the code to connect to cloud storage
#         * Train Data Download from data bucket & Cleansing
#         * Model Definition
#         * Model Compile & Fit
#         * Model Save to results bucket

# Data Preperation

# We will use LSTM to predict the signwave.

# In[3]:

from keras.callbacks import TensorBoard
import os
from os import environ

###############################################################################
# Set up working directories for data, model and logs.
###############################################################################

model_filename = "keras_lstm_v1.h5"

# writing the train model and getting input data
if environ.get('RESULT_DIR') is not None:
    output_model_folder = os.path.join(os.environ["RESULT_DIR"], "model")
    output_model_path = os.path.join(output_model_folder, model_filename)
else:
    output_model_folder = "model"
    output_model_path = os.path.join("model", model_filename)

os.makedirs(output_model_folder, exist_ok=True)

#writing metrics
if environ.get('JOB_STATE_DIR') is not None:
    tb_directory = os.path.join(os.environ["JOB_STATE_DIR"], "logs", "tb", "test")
else:
    tb_directory = os.path.join("logs", "tb", "test")

os.makedirs(tb_directory, exist_ok=True)
tensorboard = TensorBoard(log_dir=tb_directory)

###############################################################################




import numpy as np
angle = np.linspace(-np.pi, np.pi, 201)
#import matplotlib.pylab as plt
y=np.sin(angle)
#print(type(y))
#plt.plot(angle,y)


# In[4]:


import pandas as pd
values=list()
for looped in range(0,100):
    for i in range(0,len(y)):
        values.append(y[i]);


# In[5]:


time_step=list()
for i in range(0,len(values)):
        time_step.append(i);


# In[6]:


data = pd.DataFrame(
    {'time_step': time_step,
     'valuea': values,
    })


# In[7]:


#plt.plot(data['time_step'][0:800],data['valuea'][0:800])


# In[8]:


series=np.reshape(data['valuea'].values,(np.shape(data['valuea'].values)[0],1))


# We have series repeating every once in 200 cycles.
# 
# Preparing data for time series

# In[9]:


#Normalize Values
from sklearn.preprocessing import MinMaxScaler
scaler = MinMaxScaler(feature_range=(-1, 1))
scaled = scaler.fit_transform(series)
series = pd.DataFrame(scaled)


# During new data incoming, remember to use scaler used above to scale the data.

# In[10]:


window_size = 201

series_s = series.copy()
for i in range(window_size):
    series = pd.concat([series, series_s.shift(-(i+1))], axis = 1)
    
series.dropna(axis=0, inplace=True)


# In[11]:


#series.shape


# In[12]:


nrow = round(0.8*series.shape[0])


# In[13]:


train = series.iloc[:nrow, :]
test = series.iloc[nrow:,:]


# In[14]:


#test.to_csv("time_series_train.csv")
#test.to_csv("time_series_test.csv")


# In[15]:


from sklearn.utils import shuffle
train = shuffle(train)


# In[16]:


train_X = train.iloc[:,:-1]
train_y = train.iloc[:,-1]
test_X = test.iloc[:,:-1]
test_y = test.iloc[:,-1]


# In[17]:


train_X = train_X.values
train_y = train_y.values
test_X = test_X.values
test_y = test_y.values


# In[18]:


#print(train_X.shape,train_y.shape,test_X.shape,test_y.shape)


# Reshaping the data to match with LSTM

# In[19]:


train_X = train_X.reshape(train_X.shape[0],train_X.shape[1],1)
test_X = test_X.reshape(test_X.shape[0],test_X.shape[1],1)


# In[20]:


#print(train_X.shape,train_y.shape,test_X.shape,test_y.shape)


# In[21]:


time_step=train_X.shape[1]
dimension=train_X.shape[2]


# In[22]:


# In[24]:


from keras.layers.core import Dense, Activation, Dropout
from keras.layers.recurrent import LSTM
from keras.models import Sequential
#del model
# Define the LSTM model
model = Sequential()
model.add(LSTM(units=200,input_shape = (time_step,dimension),return_sequences = True))
model.add(Dropout(0.5))
model.add(LSTM(100))
model.add(Dropout(0.5))
model.add(Dense(1))
model.add(Activation("linear"))
model.compile(loss="mse", optimizer="adam")
#model.summary()


# In[25]:


#import time
#start = time.time()
history = model.fit(train_X,train_y,batch_size=512,epochs=3,validation_split=0.1,callbacks=[tensorboard])
#print("> Fit Time : ", time.time() - start)

# In[1]:

print("Training history:" + str(history.history))

score = model.evaluate(test_X, test_y, verbose=0)
print('Test loss:', score[0])
print('Test accuracy:', score[1])

# save the model
model.save(output_model_path)

